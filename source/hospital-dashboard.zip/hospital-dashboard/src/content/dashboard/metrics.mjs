import {numeric,norm} from './normalize.mjs';
export const nf=(v,d=0)=>numeric(v)?new Intl.NumberFormat('vi-VN',{maximumFractionDigits:d,minimumFractionDigits:d}).format(v):'—';
export const money=(v,scale=1e6,d=1)=>numeric(v)?nf(v/scale,d):'—';
export const GROUPS={outpatient:'Khám bệnh và ngoại trú',inpatient:'Nội trú và giường bệnh',clinical:'Cận lâm sàng',procedures:'Thủ thuật, YHCT và PHCN',education:'Truyền thông',pharmacy:'Dược',finance:'Tài chính'};
export const DEPARTMENTS=['Khám','Nội','PHCN','Phụ trĩ','CCDS'];
export const BH_MAP={all:'BV','Khám':'KHÁM BỆNH','Nội':'KHOA NỘI','PHCN':'KHOA PHCN','CCDS':'KHOA CCDS','KHOA NGOẠI':'KHOA NGOẠI'};
export function period(month,mode){
 const start=mode==='ytd'?1:mode==='quarter'?Math.floor((month-1)/3)*3+1:month;
 const months=Array.from({length:month-start+1},(_,i)=>i+start);
 const previous=mode==='month'&&month>1?[month-1]:mode==='quarter'&&month%3===0&&month>3?months.map(m=>m-3):[];
 const label=mode==='ytd'?`Lũy kế ${month} tháng/2026`:mode==='quarter'?`Quý ${Math.ceil(month/3)}/2026${month%3===0?'':` đến tháng ${month} (${months.length}/3 tháng)`}`:`Tháng ${month}/2026`;
 return {month,mode,months,previous,label};
}
const derivations={in_los:['in_days','inpatients',1],out_los:['out_days','outpatients',1],discharge_los:['discharge_days','discharged',1],improved_rate:['improved','discharged',100]};
export function act(rows,metric,months,department='all'){
 if(['occupancy_source','bed_days_per_bed'].includes(metric))return {value:null,rows:rows.filter(r=>r.metric===metric&&months.includes(r.month)&&r.department===(department==='all'?'BV':department)),status:'Chưa đủ căn cứ về giường-ngày',coverage:0};
 if(derivations[metric]){
  const [n,d,m]=derivations[metric],a=act(rows,n,months,department),b=act(rows,d,months,department);
  return {value:numeric(a.value)&&numeric(b.value)&&b.value!==0?a.value/b.value*m:null,rows:[...a.rows,...b.rows],status:b.value===0?'Mẫu số bằng 0':a.value==null||b.value==null?'Chưa đủ dữ liệu':'Tính từ tổng tử số / mẫu số',formula:`${n} / ${d}${m===100?' × 100%':''}`,coverage:Math.min(a.coverage,b.coverage)};
 }
 const selected=rows.filter(r=>r.metric===metric&&months.includes(r.month)&&r.department===(department==='all'?'BV':department));
 const byMonth=months.map(m=>selected.find(r=>r.month===m));const coverage=byMonth.filter(r=>numeric(r?.value)).length;
 const complete=coverage===months.length&&months.length>0;
 const unsupported=selected.some(r=>r.kind!=='additive');
 return {value:complete&&!unsupported?byMonth.reduce((n,r)=>n+r.value,0):complete&&months.length===1?byMonth[0].value:null,rows:selected,coverage,status:!complete?`Chưa đủ dữ liệu (${coverage}/${months.length} tháng)`:unsupported&&months.length>1?'Chưa có tử số/mẫu số phù hợp':selected.some(r=>r.status==='zero_unverified')?'Có ô 0 cần xác minh':'Theo nguồn'};
}
export function bh(rows,field,months,department='all',type='all'){
 let scope=BH_MAP[department];
 if(department==='all')scope=type==='outpatient'?'KHÁM BỆNH':type==='inpatient'?'ĐIỀU TRỊ NỘI TRÚ':'BV';
 if(department==='Khám'&&type==='inpatient'||department!=='all'&&department!=='Khám'&&type==='outpatient')scope=null;
 const selected=rows.filter(r=>r.department===scope&&months.includes(r.month));const values=months.map(m=>selected.find(r=>r.month===m)?.[field]);const coverage=values.filter(numeric).length;
 return {value:months.length&&coverage===months.length?values.reduce((a,b)=>a+b,0):null,rows:selected,coverage,status:scope==null?'Chưa có ánh xạ khoa phù hợp':coverage===months.length?'Theo nguồn':`Chưa đủ dữ liệu (${coverage}/${months.length} tháng)`};
}
export function avgBh(rows,months,department,type,denominator='visits'){
 const a=bh(rows,'total',months,department,type),b=bh(rows,denominator,months,department,type);
 return {value:numeric(a.value)&&numeric(b.value)&&b.value!==0?a.value/b.value:null,rows:a.rows,status:b.value===0?'Mẫu số bằng 0':a.value==null||b.value==null?'Chưa đủ dữ liệu':'Tổng tiền / '+(denominator==='days'?'ngày điều trị ra viện':'lượt/ca cùng phạm vi'),coverage:a.coverage};
}
export function comparison(current,previous,{rate=false}={}){
 if(!numeric(current)||!numeric(previous))return 'Chưa có kỳ so sánh tương đương';
 const diff=current-previous,sign=diff>0?'+':'';
 if(rate)return `${sign}${nf(diff,2)} điểm phần trăm`;
 if(previous===0)return `Chênh lệch ${sign}${nf(diff)}; kỳ trước bằng 0`;
 return `${sign}${nf(diff/previous*100,1)}% so kỳ trước`;
}
export function activitySummary(rows,p,department='all'){
 const unique=[...new Map(rows.filter(r=>r.month===p.month&&r.department===(department==='all'?'BV':department)).map(r=>[r.metric,r])).values()];
 return unique.map(r=>{
  const current=act(rows,r.metric,p.months,department),prev=act(rows,r.metric,p.previous,department),ytd=act(rows,r.metric,Array.from({length:p.month},(_,i)=>i+1),department);
  const planRows=rows.filter(x=>x.metric===r.metric&&x.department===r.department&&p.months.includes(x.month));
  const plan=planRows.length===p.months.length&&planRows.every(x=>numeric(x.planMonth))?planRows.reduce((n,x)=>n+x.planMonth,0):null;
  return {...r,current:current.value,cumulative:ytd.value,plan,previous:prev.value,delta:comparison(current.value,prev.value,{rate:r.unit==='%'}),notes:current.status,rows:current.rows};
 });
}
export function validActivity(rows,department,type){
 return rows.filter(r=>(department==='all'?r.department==='BV':r.department===department)&&(type==='all'||r.group!== (type==='outpatient'?'inpatient':'outpatient')));
}
export function sumStrict(rows,field,months){const values=months.map(m=>rows.find(r=>r.month===m)?.[field]);return values.length&&values.every(numeric)?values.reduce((a,b)=>a+b,0):null;}
export function groupSupport(rows,p){return [...new Set(rows.map(r=>r.label))].map(label=>{const rs=rows.filter(r=>r.label===label),cur=rs.find(r=>r.month===p.month);return {...cur,label,sourceRows:rs.filter(r=>p.months.includes(r.month)),current:sumStrict(rs,'value',p.months),cumulative:sumStrict(rs,'value',Array.from({length:p.month},(_,i)=>i+1))};});}
export function sourceText(r){return `${r.sourceFile} · ${r.sheet}!${r.cell??Object.values(r.refs??{}).join(', ')}`;}
export function exportCsv(rows,name){
 if(!rows.length)return;
 const keys=[...new Set(rows.flatMap(r=>Object.keys(r)))].filter(k=>!['rows','sourceRows'].includes(k));
 const esc=v=>{let s=v==null?'':typeof v==='object'?JSON.stringify(v):String(v);if(/^[=+\-@]/.test(s)&&!numeric(v))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';};
 const text='\ufeff'+[keys.map(esc).join(';'),...rows.map(r=>keys.map(k=>esc(r[k])).join(';'))].join('\r\n');
 const url=URL.createObjectURL(new Blob([text],{type:'text/csv;charset=utf-8;'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
export function clinicalLeaf(r){return r.group==='procedures'&&r.metric!=='procedures'&&!/^Thủ thuật loại|^Khác$/.test(r.label);}
export function qualityFindings(data,p,department,type){
 const findings=[
  {level:'Đã có căn cứ đối chiếu',title:'Thứ tự ưu tiên nguồn kế hoạch',detail:'Theo yêu cầu: ưu tiên nội dung và kế hoạch Excel; chỉ bổ sung 79/KH-BV, Phụ lục II trang 14 khi Excel chưa có. Giữ nhãn nguồn ở từng chỉ tiêu. Tỷ lệ theo Excel là tham khảo do tiêu đề năm cũ chưa xác minh.'},
  {level:'Khác nguồn kế hoạch',title:'Ngày điều trị nội trú: 78.000 / 80.000',detail:'PDF năm 2026 ghi 78.000 ngày; KE HOACH NAM!C10 ghi 80.000 và tiêu đề 2018. Đối chiếu KH năm dùng 80.000 từ Excel theo thứ tự ưu tiên được yêu cầu. PDF là nguồn tra cứu bổ sung; không ghi đè mục Excel đã có.'},
  {level:'Cần xác minh',title:'Năm trên tiêu đề',detail:'T4 ghi 2023; T5, T6, T8 ghi 2025. Kỳ 2026 đang dựa vào tên tệp và chuỗi trang tính; cần đơn vị xác nhận.'},
  {level:'Cần xác minh',title:'Công suất giường',detail:'T10!N74 = N54/H54, với H54 là ngày điều trị kế hoạch. Chưa đủ căn cứ giường-ngày để xác nhận công suất; không dùng tỷ lệ nguồn làm KPI công suất chuẩn.'},
  {level:'Chưa xác nhận chốt',title:'Mốc dữ liệu hai nguồn',detail:'File hoạt động có số T11–T12; BHYT có dữ liệu thực chất đến T10. Ô 0 công thức T11–T12 BHYT được coi là chưa nhập, không là chi phí bằng 0.'},
  {level:'Khác phạm vi',title:'Tên khoa giữa hai nguồn',detail:'Ghép Khám/KHÁM BỆNH, Nội/KHOA NỘI, PHCN/KHOA PHCN, CCDS/KHOA CCDS theo tên và nhãn điều trị trong nguồn. Phụ trĩ và KHOA NGOẠI được giữ riêng vì chưa có bảng mã khoa.'},
  {level:'Cần xác minh',title:'Thu, chi và quyết toán',detail:'Các dòng tổng thu, tổng chi và quyết toán có ô trống hoặc số 0 công thức. Chưa kết luận không có phát sinh; số tiền thuốc, hóa chất và vật tư có số được trình bày riêng.'},
 ];
 const conflicts=data.activity.filter(r=>p.months.includes(r.month)&&r.status==='source_scope_conflict'&&(department==='all'||r.department===department));
 if(conflicts.length)findings.push({level:'Lạc phạm vi trong nguồn',title:'Ô dưới cột khoa nhưng công thức khác ý nghĩa',detail:conflicts.slice(0,3).map(r=>`${r.sheet}!${r.cell} = ${r.originalValue}; ${r.formula}`).join('; ')+'. Các giá trị này được giữ trong nguồn nhưng không dùng như số khám theo khoa.'});
 if(p.month>10)findings.unshift({level:'Kỳ chưa đồng bộ',title:p.label,detail:'BHYT chưa có dữ liệu thực chất cho đủ các tháng đã chọn. Kết quả thiếu được hiển thị rõ; không thay bằng 0.'});
 if(p.month===12)findings.unshift({level:'Kỳ tương lai',title:'Tháng 12/2026',detail:'Tháng 12 chưa bắt đầu tại thời điểm nguồn được cung cấp (25/11/2026); số trong file hoạt động chỉ phục vụ tra cứu, chưa là thực hiện chính thức.'});
 const r=data.activity.filter(x=>p.months.includes(x.month)&&(department==='all'?x.department==='BV':x.department===department));
 const error=r.filter(x=>/error|no_cache/.test(x.status)).length;if(error)findings.push({level:'Lỗi nguồn',title:'Ô lỗi hoặc chưa có kết quả',detail:`Có ${error} ô trong phạm vi đang chọn. Tra cứu danh mục ánh xạ để xem ô và công thức; các ô này không được thay bằng 0.`});
 const ytd=Array.from({length:p.month},(_,i)=>i+1);let disagreements=[];
 for(const key of ['visits','inpatients','in_days','procedures','lab','out_transfer']){const a=act(data.activity,key,ytd,department);const src=a.rows.find(x=>x.month===p.month);if(numeric(a.value)&&numeric(src?.ytd)&&Math.abs(a.value-src.ytd)>1e-6)disagreements.push(`${src.label}: tổng tháng ${nf(a.value)}, ô ${src.sheet}!${src.ytdCell} ghi ${nf(src.ytd)}`);}
 if(disagreements.length)findings.push({level:'Chênh lệch nguồn',title:'Lũy kế so với tổng tháng',detail:disagreements.join('; ')});
 const costRows=bh(data.bhyt,'total',p.months,department,type).rows;
 const costDifferences=costRows.filter(r=>numeric(r.total)&&numeric(r.patientPaid)&&numeric(r.insurancePaid)&&Math.abs(r.total-r.patientPaid-r.insurancePaid)>.01);
 if(costDifferences.length)findings.push({level:'Chênh lệch số học nguồn',title:'Tổng tiền so với BN và BH thanh toán',detail:costDifferences.map(r=>`${r.sheet}!${r.refs.total} − ${r.refs.patientPaid} − ${r.refs.insurancePaid} = ${nf(r.total-r.patientPaid-r.insurancePaid,2)} đồng`).join('; ')+'. Giữ nguyên số liệu gốc, không tự cân chỉnh.'});
 return findings;
}
