"""Extract cached values and formulas without recalculating or changing the source."""
import argparse,json
from pathlib import Path
from datetime import date,datetime
from openpyxl import load_workbook
p=argparse.ArgumentParser()
p.add_argument('workbook',type=Path)
p.add_argument('output',type=Path)
a=p.parse_args()
values=load_workbook(a.workbook,data_only=True)
formulas=load_workbook(a.workbook,data_only=False)
out={'filename':a.workbook.name,'sheets':[]}
for ws in values:
 fw=formulas[ws.title];rows=[]
 for row in ws:
  cells={}
  for cell in row:
   original=fw[cell.coordinate];value=cell.value
   formula=original.value if original.data_type=='f' else None
   if value is None and formula is None:continue
   if isinstance(value,(date,datetime)):value=value.isoformat()
   cells[cell.coordinate]={'v':value,'f':formula,'t':cell.data_type}
  if cells:rows.append(cells)
 out['sheets'].append({'name':ws.title,'state':ws.sheet_state,'maxRow':ws.max_row,'maxCol':ws.max_column,'merges':[str(x) for x in ws.merged_cells.ranges],'rows':rows})
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps(out,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
print(a.output)
