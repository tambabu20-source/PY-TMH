import {normalizeActivity,normalizeBhyt} from './normalize.mjs';
const utf8=new TextDecoder();
async function unzip(buffer){
 const view=new DataView(buffer);let end=buffer.byteLength-22;
 while(end>=Math.max(0,buffer.byteLength-65557)&&view.getUint32(end,true)!==0x06054b50)end--;
 if(end<0||view.getUint32(end,true)!==0x06054b50)throw new Error('Tệp không phải Excel .xlsx hợp lệ');
 const count=view.getUint16(end+10,true);let pos=view.getUint32(end+16,true),total=0;const entries=new Map();
 if(count>3000)throw new Error('Tệp có quá nhiều thành phần');
 for(let i=0;i<count;i++){
  if(view.getUint32(pos,true)!==0x02014b50)throw new Error('Cấu trúc ZIP không hợp lệ');
  const method=view.getUint16(pos+10,true),size=view.getUint32(pos+20,true),original=view.getUint32(pos+24,true),n=view.getUint16(pos+28,true),e=view.getUint16(pos+30,true),c=view.getUint16(pos+32,true),offset=view.getUint32(pos+42,true);
  total+=original;if(total>120e6)throw new Error('Dữ liệu giải nén vượt 120 MB');
  const name=utf8.decode(new Uint8Array(buffer,pos+46,n));entries.set(name,{method,size,offset});pos+=46+n+e+c;
 }
 const cache=new Map();return async name=>{
  if(cache.has(name))return cache.get(name);const x=entries.get(name);if(!x)return null;
  const n=view.getUint16(x.offset+26,true),e=view.getUint16(x.offset+28,true),start=x.offset+30+n+e;
  const bytes=new Uint8Array(buffer,start,x.size);let result;
  if(x.method===0)result=utf8.decode(bytes);
  else if(x.method===8){try{const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));result=await new Response(stream).text();}catch{throw new Error('Trình duyệt chưa hỗ trợ giải nén Excel. Hãy dùng Chrome/Edge phiên bản hiện hành.');}}
  else throw new Error('Kiểu nén Excel chưa hỗ trợ');
  cache.set(name,result);return result;
 };
}
function xml(text){const doc=new DOMParser().parseFromString(text??'','application/xml');if(doc.querySelector('parsererror'))throw new Error('Thành phần XML trong Excel bị lỗi');return doc;}
export async function parseXlsx(file){
 if(!/\.xlsx$/i.test(file.name))throw new Error('Chọn tệp .xlsx; không đổi đuôi tệp .xls');
 if(file.size>25e6)throw new Error('Mỗi tệp tối đa 25 MB');
 const buffer=await file.arrayBuffer(),read=await unzip(buffer),workbook=xml(await read('xl/workbook.xml')),rels=xml(await read('xl/_rels/workbook.xml.rels'));
 const sharedXml=await read('xl/sharedStrings.xml');const strings=sharedXml?[...xml(sharedXml).getElementsByTagName('si')].map(si=>[...si.getElementsByTagName('t')].map(t=>t.textContent).join('')):[];
 const relationships=Object.fromEntries([...rels.getElementsByTagName('Relationship')].map(r=>[r.getAttribute('Id'),r.getAttribute('Target')]));
 const book={filename:file.name,sheets:[]};
 for(const s of workbook.getElementsByTagName('sheet')){
  const target=relationships[s.getAttribute('r:id')];if(!target)continue;
  const path=target.startsWith('/')?target.slice(1):'xl/'+target.replace(/^\.\//,'');const text=await read(path);if(!text)continue;
  const doc=xml(text),cells={};let maxRow=0,maxCol=0;
  for(const c of doc.getElementsByTagName('c')){
   const address=c.getAttribute('r'),type=c.getAttribute('t'),v=c.getElementsByTagName('v')[0]?.textContent,formula=c.getElementsByTagName('f')[0]?.textContent;
   let value=null;
   if(type==='s')value=strings[Number(v)]??null;
   else if(type==='inlineStr')value=[...c.getElementsByTagName('t')].map(t=>t.textContent).join('');
   else if(type==='str'||type==='e')value=v??null;
   else if(v!=null&&v!=='')value=Number(v);
   if(value!=null||formula!=null)cells[address]={v:value,f:formula!=null?'='+formula:null,t:type==='e'?'e':typeof value==='string'?'s':'n'};
   const match=/([A-Z]+)(\d+)/.exec(address??'');if(match){maxRow=Math.max(maxRow,Number(match[2]));maxCol=Math.max(maxCol,[...match[1]].reduce((n,l)=>n*26+l.charCodeAt(0)-64,0));}
  }
  book.sheets.push({name:s.getAttribute('name'),state:s.getAttribute('state')??'visible',maxRow,maxCol,cells});
 }
 const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',buffer))).map(v=>v.toString(16).padStart(2,'0')).join('');
 if(book.sheets.some(s=>s.name==='12 THANG 2026'))return {kind:'bhyt',data:normalizeBhyt(book),filename:file.name,hash,sheets:book.sheets.length};
 if(book.sheets.some(s=>s.name==='KE HOACH NAM')){
  const missing=Array.from({length:12},(_,i)=>'T'+(i+1)).filter(name=>!book.sheets.some(s=>s.name===name));
  if(missing.length)throw new Error('Thiếu trang tính: '+missing.join(', '));
  return {kind:'activity',data:normalizeActivity(book),filename:file.name,hash,sheets:book.sheets.length};
 }
 throw new Error('Không nhận diện được một trong hai cấu trúc báo cáo');
}
export function openStore(){return new Promise((resolve,reject)=>{const req=indexedDB.open('yhct-dashboard-files-v1',1);req.onupgradeneeded=()=>req.result.createObjectStore('files');req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
export async function readStored(){const db=await openStore();return new Promise((resolve,reject)=>{const tx=db.transaction('files','readonly'),req=tx.objectStore('files').getAll();req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);tx.oncomplete=()=>db.close();});}
export async function writeStored(item){const db=await openStore();return new Promise((resolve,reject)=>{const tx=db.transaction('files','readwrite');tx.objectStore('files').put(item,item.kind);tx.oncomplete=()=>{db.close();resolve();};tx.onerror=()=>{db.close();reject(tx.error);};});}
