import {act,nf} from './metrics.mjs';
import {numeric,norm} from './normalize.mjs';
export const PLAN_INFO={file:'Kế hoạch hoạt động năm 2026.signed.signed.pdf',document:'79/KH-BV',date:'26/12/2025',hospital:'Bệnh viện Y học cổ truyền Phú Yên',page:14,appendix:'Phụ lục II',heading:'Kế hoạch dự kiến năm 2026',asset:'./assets/ke-hoach-2026.pdf'};
const rows=[
 [1,'Tổng số lần khám bệnh','Lần','45.000',45000,'additive','visits','outpatient','Tên chỉ tiêu và đơn vị phù hợp với tổng số lần khám của báo cáo hoạt động.'],
 [2,'TS BN điều trị ngoại trú','BN','1.400',1400,'additive','outpatients','outpatient','Đối chiếu BN điều trị ngoại trú; không dùng lượt KCB BHYT thay thế.'],
 [3,'TS ngày điều trị nội trú','Ngày','78.000',78000,'additive','in_days','inpatient','Excel KE HOACH NAM!C10 ghi 80.000. Dùng PDF năm 2026 cho mẫu số KH năm, giữ nguyên số nguồn Excel.'],
 [4,'Ngày điều trị TB 1 BN','Ngày','< 25',25,'threshold-ambiguous',null,'inpatient','Phụ lục chưa nói rõ mẫu số là BN đang điều trị hay BN ra viện. Giữ hai bình quân riêng; chưa đánh giá ngưỡng này.'],
 [5,'Công suất sử dụng giường','%','>90',90,'threshold-unavailable',null,'inpatient','Chưa đủ số giường-ngày được xác minh. Không lấy tỷ lệ ngày điều trị / ngày điều trị kế hoạch làm công suất.'],
 [6,'Tỷ lệ điều trị khỏi, đỡ','%','>90',90,'threshold','improved_rate','inpatient','Tham chiếu tỷ lệ BN ra viện khỏi/đỡ trên tổng BN ra viện. Giá trị lũy kế chưa là kết quả chốt cả năm.'],
 [7,'Tỷ lệ sử dụng đông dược','%','>85',85,'threshold-ambiguous',null,'support','Excel có tỷ lệ sử dụng thuốc YHCT nhưng thiếu tử số/mẫu số đối chiếu; chưa tự đồng nhất với đông dược.'],
 [8,'Giảm tỷ lệ bệnh nhân chuyển tuyến so với năm trước','%','5–10',null,'prior-year',null,'inpatient','Chưa có tỷ lệ năm 2025 cùng phạm vi để tính mức giảm. Không dùng riêng số BN chuyển viện làm tỷ lệ.'],
 [9,'Tỷ lệ tử vong','%','<2',2,'threshold-unavailable',null,'inpatient','Chưa có tử số tử vong và mẫu số phù hợp; không thay bằng BN tiên lượng tử vong xin về.'],
 [10,'Tăng tỷ lệ đạt các tiêu chí thuộc Bộ tiêu chí đánh giá chất lượng Bệnh viện trung bình cao hơn năm trước','%','1–3',null,'prior-year',null,'quality','Thiếu bộ điểm/tiêu chí chất lượng và số so sánh năm trước.'],
 [11,'Tỷ lệ hài lòng của người dân với dịch vụ y tế','%','>90',90,'threshold-unavailable',null,'quality','Hai file Excel chưa có kết quả khảo sát hài lòng phù hợp.'],
];
export const PLAN_ROWS=rows.map(([order,label,unit,targetText,target,kind,metric,group,note])=>({order,label,unit,targetText,target,kind,metric,group,note,sourceFile:PLAN_INFO.file,page:14,sourceReference:`79/KH-BV · Phụ lục II · trang 14 · STT ${order}`,planClassification:PLAN_INFO.heading}));
export function preferredPlan(excelPlan,activity,pdfRows=PLAN_ROWS){
 const byCell=new Map(activity.filter(r=>r.month===10&&r.department==='BV'&&r.planYearCell).map(r=>[r.planYearCell,r]));
 const replacePdf={C4:1,C5:2,C10:3,C11:4,C12:5,C18:7};
 const overridden=new Set(),excel=[];
 for(const e of excelPlan){
  if(!numeric(e.value)&&!e.text)continue;
  const actual=byCell.get(e.cell),pdf=pdfRows.find(p=>p.order===replacePdf[e.cell]);
  if(pdf)overridden.add(pdf.order);
  const metric=actual?.metric??null;
  const targetText=numeric(e.value)?nf(e.value,Number.isInteger(e.value)?0:2):e.text;
  const parameter=e.cell==='C8';
  excel.push({order:0,label:e.label,unit:parameter?'giường':e.cell==='C18'?'%':actual?.unit??pdf?.unit??'Chưa rõ ĐVT',target:numeric(e.value)?e.value:null,targetText,kind:parameter?'parameter':numeric(e.value)&&actual?.kind==='additive'?'additive':metric&&['in_los','out_los'].includes(metric)?'threshold':'threshold-unavailable',metric,group:actual?.group??pdf?.group??'inpatient',origin:'Excel',sourceFile:e.sourceFile,sheet:e.sheet,cell:e.cell,formula:e.formula,sourceReference:e.sheet+'!'+e.cell,planClassification:'Kế hoạch trong Excel; tiêu đề năm 2018 cần xác minh',departments:e.departments,note:(pdf?'Ưu tiên Excel. PDF ghi '+pdf.targetText+' '+pdf.unit+'. ':'')+(parameter?'Số giường kế hoạch; chưa là số giường thực tế từng ngày.':metric?'Đối chiếu lũy kế với KH nguồn; chưa kết luận hoàn thành kế hoạch 2026 chính thức.':'Chưa có số thực hiện hoặc định nghĩa phù hợp để đối chiếu.')});
 }
 const fallback=pdfRows.filter(r=>!overridden.has(r.order)).map(r=>({...r,origin:'KH 2026',note:'Excel chưa có kế hoạch tương ứng. '+r.note}));
 return [...excel,...fallback].map((r,i)=>({...r,order:i+1}));
}
export function comparePlan(planRows,activity,p,department){
 const months=Array.from({length:p.month},(_,i)=>i+1);
 return planRows.map(r=>{
  const depPlan=department==='all'?null:r.departments?.[department];
  const compatibleDept=department!=='Phụ trĩ'&&department!=='KHOA NGOẠI';
  const target=department==='all'?r.target:compatibleDept?depPlan?.value:null;
  const targetText=department==='all'?r.targetText:numeric(target)?nf(target,Number.isInteger(target)?0:2):depPlan?.text??'Chưa có phân bổ';
  const result=r.metric?act(activity,r.metric,months,department):{value:null,rows:[],status:'Chưa đủ dữ liệu'};
  const annualPercent=r.kind==='additive'&&numeric(result.value)&&target>0?result.value/target*100:null;
  return {...r,rows:[r],target,targetText,sourceReference:department!=='all'&&depPlan? r.sheet+'!'+depPlan.cell:r.sourceReference,actual:result.value,actualDisplay:numeric(result.value)?nf(result.value,r.unit==='%'||r.kind==='threshold'?2:0)+(r.unit==='%'?'%':''):'Chưa đủ dữ liệu',completion:annualPercent,completionDisplay:numeric(annualPercent)?nf(annualPercent,2)+'%':'Không tính',period:`Lũy kế ${p.month} tháng/2026`,note:department!=='all'&&!numeric(target)&&!depPlan?.text?'Chưa có kế hoạch khoa phù hợp; không phân bổ từ KH toàn BV.':r.note,activityRows:result.rows};
 });
}
