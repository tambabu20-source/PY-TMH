export const ACTIVITY_FILE = '2026 BC BV số thực chuẩn A THUẬN.xlsx';
export const BHYT_FILE = 'BAO CAO. AVinh-BHYT.t10N 8.111.2026.xlsx';
export const GOOGLE_LINKS = { activity: 'https://docs.google.com/spreadsheets/d/18Ld8uEQ4-XfUy38QPPqLMY32z3CUuYPyWjRICcLh5os/edit', bhyt: 'https://docs.google.com/spreadsheets/d/1w1tOzfoOyeyrdNCzIwPR1GQRliSAs8ub8DjypQsnVC8/edit' };
export const clean = v => String(v ?? '').replace(/\s+/g, ' ').trim();
export const norm = v => clean(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase();
export const col = n => { let s=''; for(;n;n=Math.floor((n-1)/26)) s=String.fromCharCode(65+(n-1)%26)+s; return s; };
export const numeric = v => typeof v==='number' && Number.isFinite(v);
export function cell(sheet, address) { const c=sheet?.cells?.[address]; const value=c?.v; return { value:numeric(value)?value:null, text:typeof value==='string'?value:null, status:!c?'blank':c.t==='e'?'formula_error':c.f && value==null?'formula_no_cache':numeric(value)?value===0?'zero_unverified':'observed':value==null?'blank':'text', formula:c?.f??'', cell:address }; }
const aliases = [
 ['visits',/^tong so lan kham \(/], ['insured_visits',/^so lan kham bn co the bhyt/], ['paid_visits',/^so lan kham thu vien phi/],
 ['outpatients',/^tong so bn dieu tri ngoai tru/], ['out_days',/^tong so ngay dt ngoai tru/], ['out_los',/^ngay dieu tri tb 01 bn ngoai tru/],
 ['out_transfer',/^tong so lan kham chuyen tuyen/], ['inpatients',/^tong so bn dieu tri noi tru/], ['in_days',/^tong so ngay dieu tri noi tru/],
 ['in_los',/^ngay dieu tri tb 01 bn noi tru/], ['discharged',/^tong so bn ra vien/], ['discharge_days',/^tong so ngay ra vien/],
 ['discharge_los',/^ngay dt tb 01 bn ra vien/], ['improved',/^so bn ra vien dieu tri khoi, do/], ['improved_rate',/^ti le bn dieu tri khoi va do/],
 ['in_transfer',/^tong so bn dt noi tru chuyen vien/], ['bed_days_per_bed',/^ngay sdg/], ['occupancy_source',/^cong suat su dung giuong benh/],
 ['ultrasound',/^sieu am$/], ['ecg',/^dien tim$/], ['xray',/^x quang$/], ['lab',/^tieu ban xet nghiem/],
 ['procedures',/^thu thuat \(tong cong\)/], ['education_sessions',/^so lan truyen thong/], ['education_patients',/^so bn duoc truyen thong/],
];
export const metricId = (label,group,occ=0) => aliases.find(([,p])=>p.test(norm(label)))?.[0] ?? `${group}:${norm(label).replace(/[^a-z0-9]+/g,'_')}:${occ}`;
function unitFor(label,group) { const n=norm(label); if (/ti le|cong suat/.test(n))return '%'; if(/tieu ban|huyet hoc|sinh hoa|vi sinh/.test(n))return 'tiêu bản'; if(/ngay/.test(n))return /tb 01/.test(n)?'ngày/BN':'ngày'; if(group==='procedures'||group==='clinical'||/lan/.test(n))return 'lần'; return 'BN'; }
const annualRows={visits:4,outpatients:5,out_days:6,inpatients:9,in_days:10,out_los:7,in_los:11,occupancy_source:12,procedures:93,lab:14,ultrasound:15,ecg:16,xray:17};
const annualCols={'BV':'C','Khám':'D','Nội':'E','PHCN':'F','Phụ trĩ':'G','CCDS':'H'};
const groupHeaders={ 'KHÁM & ĐIỀU TRỊ NGOẠI TRÚ':'outpatient','ĐIỀU TRỊ NỘI TRÚ':'inpatient','XÉT NGHIỆM - CĐHA-TDCN':'clinical','THỦ THUẬT (Tổng cộng)':'procedures','TRUYỀN THÔNG GIÁO DỤC SK':'education','DƯỢC':'pharmacy','TÀI CHÍNH':'finance' };
export function normalizeActivity(book) {
 const result={activity:[],pharmacy:[],finance:[],education:[],activityMeta:[],structure:[],plan:[],audit:[]};
 const annual=book.sheets.find(s=>s.name==='KE HOACH NAM');
 const planLabels=new Map(); if(annual)for(let r=4;r<=annual.maxRow;r++){const l=clean(cell(annual,'B'+r).text);if(l)planLabels.set(norm(l),r);}
 for(const s of book.sheets) result.structure.push({source:'Hoạt động',file:book.filename,sheet:s.name,state:s.state??'visible',rows:s.maxRow,columns:s.maxCol,role:/^T\d+$/.test(s.name)?'Số tháng để tổng hợp':s.name==='KE HOACH NAM'?'Kế hoạch cần xác minh năm':'Chỉ đối chiếu; không cộng vào tháng'});
 for(const s of book.sheets.filter(s=>/^T([1-9]|1[0-2])$/.test(s.name))) {
  const month=Number(s.name.slice(1)); const title=cell(s,'A1').text??'';
  result.activityMeta.push({month,sheet:s.name,title,file:book.filename,yearConflict:!title.includes('2026')});
  let group='',subgroup='';const seen={};
  const depts=[9,10,11,12,13,14].map(n=>({name:clean(cell(s,col(n)+'3').text),n}));
  if(!depts.every(d=>d.name)||!/Thực hiện tháng/i.test(cell(s,'I2').text??'')) throw new Error(`${s.name}: cấu trúc cột thực hiện không phù hợp`);
  for(let r=4;r<=s.maxRow;r++){
   const label=clean(cell(s,'B'+r).text);if(!label)continue;
   const gh=groupHeaders[label];if(gh){group=gh;subgroup='';if(group!=='procedures')continue;}
   if(!group)continue;
   if(group==='pharmacy'){
    if(/^(Thuốc thành phẩm|Thuốc tân dược)/i.test(label)||!/^Số lượng|^Thành tiền/.test(label)){
     const record={month,label,sourceFile:book.filename,sheet:s.name,row:r,unit:/\(([^)]+)\)/.exec(label)?.[1]??(/thang/i.test(label)?'thang':'Chưa rõ ĐVT')};
     for(const [k,c] of Object.entries({production:'C',productionYtd:'D',quantity:'E',amount:'F',quantityYtd:'G',amountYtd:'H'})){const x=cell(s,c+r);record[k]=x.value;record[k+'Cell']=c+r;record[k+'Formula']=x.formula;record[k+'Status']=x.status;}
     result.pharmacy.push(record);
    }continue;
   }
   if(group==='finance'){
    const x=cell(s,'C'+r),y=cell(s,'G'+r);result.finance.push({month,label,indicatorCode:clean(s.cells?.['A'+r]?.v),sourceFile:book.filename,sheet:s.name,cell:'C'+r,formula:x.formula,value:x.value,ytd:y.value,ytdCell:'G'+r,ytdFormula:y.formula,status:x.status,unit:/Tỉ lệ|Tỷ lệ/.test(label)?'%':'đồng'});continue;
   }
   if(group==='education' && label.startsWith('Khoa')){result.education.push({month,department:label,text:cell(s,'I'+r).text??'',sourceFile:book.filename,sheet:s.name,cell:'I'+r});continue;}
   if(label==='Nội dung truyền thông')continue;
   if(/^Thủ thuật loại|^Khác$/.test(label))subgroup=label;
   const occurrence=seen[group+'|'+norm(label)]??0;seen[group+'|'+norm(label)]=occurrence+1;
   const metric=metricId(label,group,occurrence),unit=unitFor(label,group);
   const kind=unit==='%'?'rate':/TB 01|Ngày SDG/.test(label)?'average':'additive';
   let planRow=annualRows[metric]??planLabels.get(norm(label));
   for(const d of depts){
    const x=cell(s,col(d.n)+r),y=cell(s,col(d.n+18)+r),p=cell(s,col(d.n-6)+r),py=cell(s,col(d.n+12)+r);
    if(x.value==null && x.status==='text') continue;
    const ac=planRow&&annualCols[d.name]?annualCols[d.name]+planRow:null;const ap=ac?cell(annual,ac):null;
    const conflict=group==='outpatient'&&!['Khám','BV'].includes(d.name);
    result.activity.push({month,metric,label,group,subgroup,kind,unit,department:d.name,value:conflict?null:x.value,status:conflict&&numeric(x.value)?'source_scope_conflict':x.status,originalValue:x.value,sourceFile:book.filename,sheet:s.name,cell:x.cell,formula:x.formula,ytd:conflict?null:y.value,ytdCell:y.cell,ytdFormula:y.formula,ytdStatus:y.status,planMonth:p.value,planMonthCell:p.cell,planMonthFormula:p.formula,planYtd:py.value,planYtdCell:py.cell,planYear:ap?.value??null,planYearCell:ac,planStatus:'Cần xác minh năm kế hoạch'});
   }
  }
 }
 if(annual) for(let r=4;r<=annual.maxRow;r++){const label=clean(cell(annual,'B'+r).text);if(label)result.plan.push({label,sourceFile:book.filename,sheet:annual.name,cell:'C'+r,value:cell(annual,'C'+r).value,text:cell(annual,'C'+r).text,formula:cell(annual,'C'+r).formula,departments:Object.fromEntries(Object.entries(annualCols).map(([dep,c])=>[dep,{value:cell(annual,c+r).value,text:cell(annual,c+r).text,cell:c+r,formula:cell(annual,c+r).formula}])),status:'Cần xác minh năm kế hoạch'});}
 return result;
}
export const BH_FIELDS={visits:'B',days:'C',total:'D',patientPaid:'E',insurancePaid:'F',exam:'G',bed:'H',lab:'I',imaging:'J',drugs:'K',technical:'L',supplies:'M'};
export function normalizeBhyt(book){
 const s=book.sheets.find(s=>s.name==='12 THANG 2026');if(!s)throw new Error('Không tìm thấy sheet 12 THANG 2026');
 if(!/T_TONGCHI/.test(cell(s,'D3').text??''))throw new Error('Không xác nhận được cột tổng tiền T_TONGCHI');
 const result={bhyt:[],bhytMeta:[],structure:[]};let month=null,annual=false;
 for(const t of book.sheets)result.structure.push({source:'BHYT',file:book.filename,sheet:t.name,state:t.state??'visible',rows:t.maxRow,columns:t.maxCol,role:t.name===s.name?'Theo dõi tháng; không cộng dòng năm':'Không đưa vào tổng BHYT'});
 for(let r=5;r<=s.maxRow;r++){
  const label=clean(cell(s,'A'+r).text);if(!label)continue;
  const m=/THÁNG\s*(\d+)/i.exec(label);if(m){month=Number(m[1]);annual=false;}else if(/^NĂM/i.test(label)){annual=true;month=null;}
  if(month==null||annual)continue;
  const scope=m?'BV':label;
  const rec={month,department:scope,label,sourceFile:book.filename,sheet:s.name,row:r,refs:{},formulas:{},statuses:{}};
  for(const [k,c] of Object.entries(BH_FIELDS)){const x=cell(s,c+r);rec[k]=x.value;rec.refs[k]=c+r;rec.formulas[k]=x.formula;rec.statuses[k]=x.status;}
  result.bhyt.push(rec);
 }
 for(let m=1;m<=12;m++){
  const rs=result.bhyt.filter(r=>r.month===m);const observed=rs.some(r=>r.department!=='BV'&&r.total>0&&Object.entries(r.formulas).some(([k,f])=>!f&&numeric(r[k])&&r[k]>0));
  result.bhytMeta.push({month:m,available:observed,file:book.filename,sheet:s.name});
  if(!observed)for(const r of rs)for(const k of Object.keys(BH_FIELDS)){r[k]=null;r.statuses[k]='unentered';}
 }
 return result;
}
export function rawBook(raw){return {filename:raw.filename,sheets:raw.sheets.map(s=>({...s,cells:s.cells??Object.assign({},...s.rows)}))};}
