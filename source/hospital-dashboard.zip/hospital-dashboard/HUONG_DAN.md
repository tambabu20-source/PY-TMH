# Dashboard hoạt động bệnh viện và chi phí BHYT

Mở bản đã đóng gói tại `YHCT_DASHBOARD/index.html`. Bản này chứa dữ liệu đầy đủ, không cần CDN. Để sử dụng ổn định chức năng nhập Excel và lưu trên trình duyệt, phục vụ thư mục bằng một máy chủ HTTP cục bộ hoặc triển khai gói GitHub Pages. Bản xem trước trên máy hiện tại: http://127.0.0.1:4173/?view=1&tab=hospital.

## Sử dụng

1. Chọn tháng kết thúc và chế độ trong tháng, quý đến tháng chọn hoặc lũy kế. Mặc định T10/2026 để đối chiếu hai file; đây chưa phải xác nhận đã chốt.
2. Chọn toàn bệnh viện hoặc khoa, nhóm chỉ tiêu và phạm vi điều trị. Các mục nguồn chưa tách ngoại trú/nội trú có ghi chú riêng. Bảng rộng cuộn trong khung.
3. Bấm số KPI hoặc chỉ tiêu để xem file, sheet, ô và công thức. Menu trên thẻ có nguồn và xuất dữ liệu; mỗi bảng có Xuất CSV.
4. Mở **Nhập lại Excel và quản lý dữ liệu**, chọn một hoặc hai file cùng cấu trúc, xem trước rồi **Áp dụng**. Bản mới thay thế theo loại file, không cộng trùng. Công thức sử dụng kết quả đã lưu: cần tính lại và lưu bằng Excel nếu công thức vừa thay đổi.
5. **In báo cáo tóm tắt** dùng A4 dọc; **In toàn bộ/In mục** dùng A4 hoặc A3 ngang. Bản in bao gồm các dòng đang thu gọn thuộc phạm vi chọn. Trong khung bản in, bấm **In / Lưu PDF**, chọn máy in PDF. Có thể lưu HTML bản in để mở lại.
6. Ba nhãn đầu trang mở hai Google Sheets và kế hoạch PDF. Hai Google Sheets đã được gắn dấu sao. Các bản này không tự đồng bộ với file nhập mới trên dashboard.

## Quy tắc nguồn đã áp dụng

Ưu tiên nội dung và kế hoạch trong Excel. Chỉ bổ sung KH 2026 khi Excel chưa có chỉ tiêu tương ứng. Mỗi dòng kế hoạch ghi rõ nguồn và vị trí; 64 mục từ Excel, 5 mục bổ sung PDF. Ngày điều trị nội trú dùng **80.000** tại `KE HOACH NAM!C10`; PDF ghi **78.000** được giữ ở ghi chú. Bình quân nội trú dùng ngưỡng Excel **<17**; công suất mục tiêu giữ Excel **>100**, chưa tự lấy ngưỡng PDF để ghi đè.

Excel còn tiêu đề kế hoạch năm 2018 và một số tháng năm cũ. Tỷ lệ LK/KH Excel là đối chiếu tham khảo, chưa kết luận hoàn thành KH 2026 chính thức. Không chia kế hoạch năm đều cho tháng. Các kế hoạch khoa phải có ô nguồn và tên khoa phù hợp; Phụ trĩ/Ngoại phụ chưa tự đồng nhất. PDF không cung cấp phân bổ khoa.

## Dữ liệu và triển khai

Gói `YHCT_DASHBOARD_GITHUB_PAGES.zip` chứa `index.html`, snapshot JSON hiện tại, PDF kế hoạch trong `assets/`, mẫu PDF và hướng dẫn. Đưa nguyên nội dung gói vào một repository riêng, chọn Settings → Pages → Deploy from a branch → thư mục gốc. Dữ liệu trong gói sẽ được công bố theo quyền truy cập của website; gói mới được chuẩn bị, chưa được đăng lên GitHub.

Mọi tính toán và nhập Excel chạy tại trình duyệt. IndexedDB lưu file đã chuẩn hóa tại trình duyệt/địa chỉ website đó. Dữ liệu nhập trên một máy không tự chuyển sang máy khác, Google Sheets hoặc bản website khác. Mở cùng gói offline và localhost là hai vùng lưu trữ riêng.

## Mã nguồn

`src/content/dashboard/` chứa giao diện, chuẩn hóa, tính toán, nhập Excel, kế hoạch và bản in. `src/data.json` là snapshot đã kiểm tra. `src/content/input-data/` chứa bản trích giá trị/công thức nguyên nguồn để tái tạo. Không cần file Excel gốc để chạy gói đã đóng.

Kiểm tra số liệu: `node src/content/dashboard/data-check.mjs`.

Tái tạo snapshot: `node src/content/dashboard/prepare-data.mjs`.

Trích lại Excel: `python src/content/dashboard/extract-excel.py <file.xlsx> src/content/input-data/activity-raw.json` (hoặc `bhyt-raw.json`), cần openpyxl. Script giữ giá trị đã lưu và công thức, không tính lại Excel. Kiểm tra cấu trúc và chạy lại kiểm tra số liệu khi thay nguồn.

Build bằng Data plugin đã cài: `node <data-plugin>/output_formats/html/scripts/data-app.mjs build --project-dir <project> --separate-data`. Theo `AGENTS.md`, chỉ sửa nội dung được phép; không sửa runtime. Sau build, sao chép `src/content/assets/ke-hoach-2026.pdf` vào `dist/assets/ke-hoach-2026.pdf`. Phục vụ toàn bộ `dist` qua HTTP; không chỉ sao chép mỗi index.html.

Xuất HTML offline: `node <data-plugin>/output_formats/html/scripts/data-app.mjs export-html --project-dir <project> --output <project>/.data-app-offline/exports/dashboard.html`.

## Kiểm tra đã thực hiện

Đối chiếu KPI tháng 10 và lũy kế với ô nguồn, tổng khoa với BV, bình quân có trọng số, tháng BHYT chưa nhập, quý thiếu tháng, ưu tiên Excel, bổ sung PDF khi thiếu và giữ số 0 nguồn. Đã thử nhập hai file gốc, nhập lại thay thế không tăng số dòng; kiểm tra bộ lọc, nguồn dữ liệu, xuất HTML bản in và các khổ màn hình 360/390/768/1024/1440 px.

PDF mẫu được dựng từ chính nội dung HTML bản in xuất trong dashboard bằng ReportLab, giữ số liệu, bảng và biểu đồ vector. Hộp thoại in Chrome trong phiên kiểm tra không phản hồi; không coi đó là kiểm tra in PDF trực tiếp thành công. Xem các PDF mẫu để đối chiếu. Nội dung đầy đủ giữ các bảng thu gọn; bản tóm tắt chọn KPI, kế hoạch chính, xu hướng, cơ cấu BHYT và ghi chú trọng yếu.
