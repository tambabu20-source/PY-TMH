# Các điểm dữ liệu cần xác minh

- `KE HOACH NAM!A1` ghi năm 2018. Các tháng T4 ghi 2023; T5, T6, T8 ghi 2025. Kỳ 2026 dựa vào tên file và chuỗi trang tính, chưa là xác nhận chốt.
- Theo ưu tiên nguồn được yêu cầu, dùng 80.000 ngày nội trú từ Excel thay cho 78.000 trong PDF. Các khác biệt ngưỡng cũng giữ Excel trước, có ghi chú PDF ở từng dòng. Không sửa file gốc.
- Hoạt động có số T11–T12; BHYT có số thực chất đến T10. T12 là kỳ tương lai tại thời điểm nhận nguồn 25/11/2026. Không dùng số 0 công thức BHYT T11–T12 như chi phí bằng 0.
- Công suất nguồn `T10!N74=N54/H54` dùng ngày điều trị kế hoạch làm mẫu số. Số giường kế hoạch 285 chưa thay được số giường thực tế theo ngày; công suất chuẩn còn thiếu căn cứ giường-ngày.
- `T10!J5=I5-I6` là giá trị 2.401 dưới cột Nội nhưng có ý nghĩa số nam trong nhóm khám. Giữ nguyên giá trị gốc để tra cứu, loại khỏi số khám khoa Nội.
- Khám/KHÁM BỆNH, Nội/KHOA NỘI, PHCN/KHOA PHCN, CCDS/KHOA CCDS có căn cứ nhãn. Chưa ghép Phụ trĩ với KHOA NGOẠI ở file BHYT hoặc Ngoại phụ ở kế hoạch năm khi chưa có mã khoa.
- Lần khám, BN đang điều trị, BN ra viện, lượt/ca BHYT là các phạm vi riêng. Trùng số không chứng minh cùng tập người bệnh. Không suy ra người bệnh duy nhất.
- Tổng lũy kế khám chuyển tuyến đến T10 từ tháng là 106, còn `T10!AF33` ghi 100. Dashboard tính lũy kế từ các tháng và trình bày chênh lệch.
- BHYT tháng 7 dòng tổng BV: `12 THANG 2026!D53-E53-F53` chênh khoảng -6 đồng. Giữ chính xác nguồn, không tự cân chỉnh tổng với các thành phần.
- Thu/chi/quyết toán có số 0 công thức hoặc ô trống; chưa kết luận không phát sinh. Một số ô tiền thuốc lũy kế có quy mô khác thường được giữ nguyên, cần đối chiếu đơn vị/công thức. BH thanh toán là T_BHTT, chưa xác nhận đã quyết toán/chuyển tiền.
- Một số dòng sản xuất dược có giá trị lớn dưới tiêu đề số lượng, có dòng thiếu đơn vị. Không cộng dòng tổng với chi tiết, không tự đổi thành tiền hoặc số lượng.
- Tỷ lệ đông dược chưa có tử số/mẫu số phù hợp để đồng nhất với tỷ lệ thuốc YHCT trong Excel. Tỷ lệ tử vong không thay bằng BN tiên lượng tử vong xin về. Chỉ tiêu giảm chuyển tuyến và chất lượng cần số năm trước; hài lòng cần khảo sát phù hợp.
- PDF kế hoạch số 79/KH-BV ngày 26/12/2025, Phụ lục II trang 14 dùng nhãn “Kế hoạch dự kiến năm 2026”. Đã đọc nội dung, không xác thực chữ ký số hoặc thay thế xác nhận văn bản của đơn vị.
